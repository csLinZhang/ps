%Lin Zhang, School of Software Engineering, Tongji University, Jan. 2017
%this script is used to draw the curve of missingRate VS FPPI (false
%positive per image) for marking-point detection algorithms

radiusAsFound = 10;
%marking-points for test images are detected and stored in
%'markingPointDetResult.mat'. Each marking-point is reprsented as a
%bounding-box [x y w h], and the center of the bounding-box is deemed as
%the position of the marking-point
markingPointDetResult = load('markingPointDetResult.mat');
markingPointDetResult = markingPointDetResult.markingPointDetResult;

%The foloder 'ForMarkingPoints' contains ground-truth data for testing the
%performance of marking-point detection
testImgFiles = dir('ForMarkingPoints\*.bmp');
dt = cell(length(testImgFiles),1);
gt = cell(length(testImgFiles),1);

for index = 1:length(testImgFiles)
    currentImgFileName = testImgFiles(index).name;
    bbsForThisImg = markingPointDetResult{index};
    
    zeroVec = zeros(size(bbsForThisImg,1),1);
    
    bbsForThisImg = [bbsForThisImg zeroVec];
    
    
    nameLength = length(currentImgFileName);
    labelData = load(['ForMarkingPoints\' currentImgFileName(1:nameLength-4) '.mat']);
    
    labelData = labelData.marks;
    thisGt = zeros(size(labelData,1),5);
    
    for bbsIndex = 1:size(bbsForThisImg,1)
        centerPosX = bbsForThisImg(bbsIndex,1) + bbsForThisImg(bbsIndex,3)/2;
        centerPosY = bbsForThisImg(bbsIndex,2) + bbsForThisImg(bbsIndex,4)/2;
        
        bestMatchGtIndex = 0;
        bestMatchDist = Inf;
        for gtPosIndex = 1:size(labelData,1)
            if thisGt(gtPosIndex, 5) == 1 %this Gt has already been matched
                continue; 
            end
            
            gtPosX = labelData(gtPosIndex,1);
            gtPosY = labelData(gtPosIndex,2);
                
            distToCurrentGt = (gtPosY-centerPosY)^2 + (gtPosX-centerPosX)^2;
            if distToCurrentGt <= radiusAsFound^2 
                if distToCurrentGt<bestMatchDist
                    bestMatchDist = distToCurrentGt;
                    bestMatchGtIndex = gtPosIndex;
                end
            end
        end
        
        if bestMatchGtIndex ~= 0
            bbsForThisImg(bbsIndex,6) = 1;
            thisGt(bestMatchGtIndex, 5) = 1;
        end
    end

    dt{index} = bbsForThisImg;
    gt{index} = thisGt;
end 

ref = 10.^(-2:.25:0);
[fp,tp,~,miss] = bbGt('compRoc',gt,dt,1,ref);
miss=exp(mean(log(max(1e-10,1-miss)))); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% optionally plot roc
lims = [3.1e-3 1e1 .05 1];
figure(1); 
plotRoc([fp tp],'logx',1,'logy',1,'xLbl','fppi',...
  'lims',lims,'color','g','smooth',1,'fpTarget',ref);
title(sprintf('log-average miss rate = %.2f%%',miss*100));

