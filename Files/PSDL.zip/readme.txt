This is the demo matlab source code for the PSDL parking-slot detection algorithm
1. Make sure that the folder 'test images' containg test images is existinng at the root folder of the program
2. Run main.m
3. It will output 'detectResults.mat' at the root folder of the program.