function varargout = test(varargin)
% TEST MATLAB code for test.fig
%      TEST, by itself, creates a new TEST or raises the existing
%      singleton*.
%
%      H = TEST returns the handle to a new TEST or the handle to
%      the existing singleton*.
%
%      TEST('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TEST.M with the given input arguments.
%
%      TEST('Property','Value',...) creates a new TEST or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before test_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to test_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help test

% Last Modified by GUIDE v2.5 23-Jul-2016 18:57:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @test_OpeningFcn, ...
                   'gui_OutputFcn',  @test_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before test is made visible.
function test_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to test (see VARARGIN)

% Choose default command line output for test
handles.output = hObject;

handles.readSuccess = 0;
set(gcf, 'WindowButtonDownFcn', @getMousePositionOnImage);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes test wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = test_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function FolderPath_Callback(hObject, eventdata, handles)
% hObject    handle to FolderPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FolderPath as text
%        str2double(get(hObject,'String')) returns contents of FolderPath as a double


% --- Executes during object creation, after setting all properties.
function FolderPath_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FolderPath (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ReadImage.
function ReadImage_Callback(hObject, eventdata, handles)
% hObject    handle to ReadImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
path = get(handles.FolderPath, 'String');
if ~exist(path, 'dir')
    set(handles.ReadResult, 'String', 'The path is not valid!');
    return;
end
formats = get(handles.ImageFormat, 'String');
dirs = dir([path,'\*.',formats{get(handles.ImageFormat, 'Value')}]);
if isempty(dirs)
    set(handles.ReadResult, 'String', 'There is no image under this path!');
    return;
end
%imshow([path,'\',dirs(1).name]);
set(handles.ReadResult, 'String', [num2str(size(dirs, 1)), ' images read!']);
handles.readSuccess = 1;
handles.imagePath = [path, '\'];
handles.images = dirs;
handles.imageIndex = 1;
loadImageAndMarks(hObject, handles);

% --- Executes on button press in SaveMark.
function SaveMark_Callback(hObject, eventdata, handles)
% hObject    handle to SaveMark (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~handles.readSuccess
    set(handles.LoadResult, 'String', 'Select folder first!');
    return;
end
name = [handles.imagePath, handles.images(handles.imageIndex).name];
name(end - 2 : end) = 'mat';
save(name, '-struct', 'handles', 'marks');
set(handles.LoadResult, 'String', 'Save Success!');

% --- Executes on button press in LodeLastImage.
function LodeLastImage_Callback(hObject, eventdata, handles)
% hObject    handle to LodeLastImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~handles.readSuccess
    set(handles.LoadResult, 'String', 'Select folder first!');
    return;
end
if handles.imageIndex == 1
    set(handles.LoadResult, 'String', 'It is the first image!');
    return;
end
handles.imageIndex = handles.imageIndex - 1;
guidata(hObject, handles);
loadImageAndMarks(hObject, handles);

% --- Executes on button press in LoadNextImage.
function LoadNextImage_Callback(hObject, eventdata, handles)
% hObject    handle to LoadNextImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~handles.readSuccess
    set(handles.LoadResult, 'String', 'Select folder first!');
    return;
end
if handles.imageIndex == size(handles.images, 1)
    set(handles.LoadResult, 'String', 'It is the last image!');
    return;
end
handles.imageIndex = handles.imageIndex + 1;
guidata(hObject, handles);
loadImageAndMarks(hObject, handles);

% --- Executes on button press in ChooseFolder.
function ChooseFolder_Callback(hObject, eventdata, handles)
% hObject    handle to ChooseFolder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
dname = uigetdir();
if dname ~= 0
    set(handles.FolderPath, 'String', dname);
end

% --- Executes on mouse press over axes background.
function AxesImage_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to AxesImage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function loadImageAndMarks(hObject, handles)
name = [handles.imagePath, handles.images(handles.imageIndex).name];
if ~exist(name, 'file')
    set(handles.LoadResult, 'String', 'The image does not exist');
else
    hold off;
    handles.isFirstClick = 1;
    set(gcf, 'WindowButtonMotionFcn', '');
    imshow(name);
    set(handles.ImageFileName, 'String', ['No.', num2str(handles.imageIndex),': ', handles.images(handles.imageIndex).name]);
    set(handles.LoadResult, 'String', 'Load Success!');
    name(end - 2 : end) = 'mat';
    if exist(name, 'file')
        data = load(name);
        handles.marks = data.marks;
        handles.markPlots = [];
        hold on;
        for i = 1:size(handles.marks, 1)
            theta = linspace(0,2*pi);
            x1 = 10*cos(theta) + handles.marks(i, 1);
            y1 = 10*sin(theta) + handles.marks(i, 2);
            x2 = [handles.marks(i, 1), handles.marks(i, 3)];
            y2 = [handles.marks(i, 2), handles.marks(i, 4)];
            handles.markPlots = [handles.markPlots; [plot(x1,y1,'r','LineWidth',1), plot(x2,y2,'b'), plot(handles.marks(i, 3),handles.marks(i, 4),'bx')]];
        end
    else
        handles.marks = [];
        handles.markPlots = [];
    end
    guidata(hObject, handles);
end



function PageToTurn_Callback(hObject, eventdata, handles)
% hObject    handle to PageToTurn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PageToTurn as text
%        str2double(get(hObject,'String')) returns contents of PageToTurn as a double


% --- Executes during object creation, after setting all properties.
function PageToTurn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PageToTurn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in TurnToPage.
function TurnToPage_Callback(hObject, eventdata, handles)
% hObject    handle to TurnToPage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~handles.readSuccess
    set(handles.LoadResult, 'String', 'Select folder first!');
    return;
end
page = str2num(get(handles.PageToTurn, 'String'));
page = page(1);
if page == fix(page) && page > 0 && page <= size(handles.images, 1)
    handles.imageIndex = page;
    loadImageAndMarks(hObject, handles);
else
    set(handles.LoadResult, 'String', 'Invaid Index!');
end


% --- Executes on selection change in ImageFormat.
function ImageFormat_Callback(hObject, eventdata, handles)
% hObject    handle to ImageFormat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ImageFormat contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ImageFormat


% --- Executes during object creation, after setting all properties.
function ImageFormat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ImageFormat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
