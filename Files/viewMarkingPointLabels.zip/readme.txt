This tool is used to label (and view) marking-points of surround-view images.
Run Test.m
Then, click "selectFolder" button to specify the folder containing training positive images. Then, click "Load"