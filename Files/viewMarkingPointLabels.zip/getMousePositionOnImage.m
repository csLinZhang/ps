function getMousePositionOnImage(src, event)

handles = guidata(src);
if ~handles.readSuccess
    return;
end
cursorPoint = get(handles.AxesImage, 'CurrentPoint');
curX = cursorPoint(1,1);
curY = cursorPoint(1,2);

xLimits = get(handles.AxesImage, 'xlim');
yLimits = get(handles.AxesImage, 'ylim');

if (curX > min(xLimits) && curX < max(xLimits) && curY > min(yLimits) && curY < max(yLimits))
    %disp(['Cursor coordinates are (' num2str(curX) ', ' num2str(curY) ').']);
    hold on;
    if handles.isFirstClick
        if strcmp(get(handles.figure1,'selectionType'), 'normal')
            handles.hl = line('XData', curX, 'YData', curY, 'color', 'b');
            handles.firstClickMark = [curX, curY];
            theta = linspace(0,2*pi);
            x = 10*cos(theta) + curX;
            y = 10*sin(theta) + curY;
            handles.firstClickMarkPlot = plot(x,y,'r','LineWidth',1);
            handles.isFirstClick = 0;
            src.WindowButtonMotionFcn = @wbmcb;
        elseif strcmp(get(handles.figure1,'selectionType'), 'alt')
            for i = 1:size(handles.marks, 1)
                if norm(handles.marks(i, 1:2) - [curX, curY]) < 10
                    handles.marks(i, :) = [];
                    delete(handles.markPlots(i, :));
                    handles.markPlots(i, :) = [];
                    break;
                end
            end
        end
    else
        if strcmp(get(handles.figure1,'selectionType'), 'normal')
            handles.isFirstClick = 1;
            src.WindowButtonMotionFcn = '';
            handles.marks = [handles.marks; [handles.firstClickMark, curX, curY]];
            handles.markPlots = [handles.markPlots; [handles.firstClickMarkPlot, handles.hl, plot(curX,curY,'bx')]];
        elseif strcmp(get(handles.figure1,'selectionType'), 'alt')
            handles.isFirstClick = 1;
            src.WindowButtonMotionFcn = '';
            delete(handles.hl);
            delete(handles.firstClickMarkPlot);
        end
    end
    guidata(src, handles);
end

end

function wbmcb(src, callbackdata)
    handles = guidata(src);
    cp = get(handles.AxesImage, 'CurrentPoint');
    handles.hl.XData = [handles.firstClickMark(1), cp(1,1)];
    handles.hl.YData = [handles.firstClickMark(2), cp(1,2)];
end
